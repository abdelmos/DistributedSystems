import java.rmi.*;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Vector;

import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

public class ChatClient {
	@Option(name="-username", usage="User name that Identify User")
	public String mUserName = "";
	@Option(name="-server", usage="RMI Address and port to connect To")
	public String mRmiServer = "localhost";
	@Option(name="-p",usage="Port the client is Listening on")
    public  int mPort = 9999;
	@Option(name="-h", usage="Advertised machine Address")
	public  String mAddress = "localhost";
	
	public RegistrationInfo mCurrentReg = null; 
	
	public void ParseAgruments(String[] argv)
	{
		  CmdLineParser parser = new CmdLineParser(this);
	        try {
	            // parse the arguments.
	            parser.parseArgument(argv);
	            System.out.println("Connecting to MRI Address "+ mRmiServer);
	            System.out.println("Client is Listening on "+ mAddress+ " and port " + mPort);
	            mCurrentReg = new RegistrationInfo(mUserName, mAddress, mPort, true);
	        } catch( CmdLineException e ) {
	            // if there's a problem in the command line,
	            // you'll get this exception. this will report
	            // an error message.
	            System.err.println(e.getMessage());
	            System.err.println("java SampleMain [options...] arguments...");
	            // print the list of available options
	            parser.printUsage(System.err); 
	            System.err.println();

	            return;
	        }
	}
	public void BroadcastMessage (String msg,PresenceService presneceService ){
		try{
			Vector<RegistrationInfo>friends = presneceService.listRegisteredUsers();
			Iterator<RegistrationInfo> it = friends.iterator();
			RegistrationInfo friend = null;
			while (it.hasNext())
			{
				friend = it.next(); 
				if (!friend.getUserName().contentEquals(this.mCurrentReg.getUserName()) && friend.getStatus()){
					SendMessage(msg, friend);
				}
			}
		}
	 catch(Exception e )
		{
		 System.out.println("BroadcastMessage exception: " + e);
		}
	 
	}
	public void SendMessage (String msg, RegistrationInfo remotRegistration)
	{
		
	}
	public void ListUsers (PresenceService presneceService)
	{
		try{
			Vector<RegistrationInfo>friends = presneceService.listRegisteredUsers();
			Iterator<RegistrationInfo> it = friends.iterator();
			RegistrationInfo friend = null;
			while (it.hasNext())
			{
				friend = it.next(); 
				 System.out.println(" " + friend.getUserName()+" "+ friend.getStatus());
			}
		}
	 catch(Exception e )
		{
		 System.out.println("BroadcastMessage exception: " + e);
		}
	}
	public void Menu(PresenceService presneceService)
	{
		System.out.println("\t****Welcome to Chat Client****");
		System.out.println("Please enter commands");
		boolean exit = false;
		Scanner input = new Scanner(System.in);
		String msg = "";
		try{
			
			do{			
				String command = input.next();
				switch(command.toLowerCase())
				{
					case "friends":
						ListUsers(presneceService);
						break;
					case "talk":
						String remoteUser = input.next();
						msg = input.nextLine();
						RegistrationInfo remoteReg = presneceService.lookup(remoteUser);
						if (remoteReg!= null)
						{
							SendMessage(msg, remoteReg);
						}
						
						break;
					case "broadcast":
						msg =  input.nextLine();
							BroadcastMessage(msg,presneceService);
						break;
					case "busy":
						if ( !mCurrentReg.getStatus())
						{
							System.out.println("Your status is already busy");
						}
						else
						{
							mCurrentReg.setStatus(false);;
							presneceService.updateRegistrationInfo(mCurrentReg);
						}
		
						break;
					case "available":
						if ( mCurrentReg.getStatus())
						{
							System.out.println("Your status is already available");
						}
						else
						{
							mCurrentReg.setStatus(true);;
							presneceService.updateRegistrationInfo(mCurrentReg);
						}
						break;
					case "exit":
						 exit = true;
						 presneceService.unregister(mCurrentReg.getUserName());
						break;
				}
				
			}while(!exit);
		}
		catch(Exception e)
		{
			System.out.println("HelloClient exception: " + e);
		}
		
		input.close();
		System.out.println("bye!!");
	}

	public static void main (String[] args) 
	{
		PresenceService mService;
		try 
		{
		   if (System.getSecurityManager() == null)
		   {
		        System.setSecurityManager(new SecurityManager());
		   }
		   ChatClient mChatClient= new ChatClient();
		   mChatClient.ParseAgruments(args);
		   mService = (PresenceService)Naming.lookup("rmi://"+mChatClient.mRmiServer+"/ABC");		
		   Boolean isSuccess= mService.register(mChatClient.mCurrentReg);
		   if (!isSuccess)
		   {
			System.out.println("Registeration Failed! with User Name " + mChatClient.mCurrentReg.getUserName() );
		   }
			//Start Server Thread
		
		   //Start Command Loop
			mChatClient.Menu(mService);
			// stop thread
		}
		catch (Exception e)
		{
			System.out.println("HelloClient exception: " + e);
		}
	}
}
