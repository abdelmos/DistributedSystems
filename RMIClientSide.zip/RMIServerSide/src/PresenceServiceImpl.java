

import java.rmi.*;
import java.rmi.server.*;
import java.util.Vector;   
 
public class PresenceServiceImpl extends UnicastRemoteObject
implements PresenceService {

	private static final long serialVersionUID = 1L;

	protected PresenceServiceImpl() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	public static void main (String[] argv) {
		   try {
			  
			   ComandLineArg arg = new ComandLineArg();
			   arg.ParseArguments(argv);
			   if (System.getSecurityManager() == null) {
		            System.setSecurityManager(new SecurityManager());
		        }
 
			   PresenceService Hello = new PresenceServiceImpl();
			   Naming.rebind("rmi://localhost:"+arg.num+"/ABC", Hello);
 
			   System.out.println("Persense Server is ready.");
			   }catch (Exception e) {
				   System.out.println("Presense Server failed: " + e);
				}
		   }

	@Override
	public boolean register(RegistrationInfo reg) throws RemoteException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateRegistrationInfo(RegistrationInfo reg) throws RemoteException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void unregister(String userName) throws RemoteException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public RegistrationInfo lookup(String name) throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Vector<RegistrationInfo> listRegisteredUsers() throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}
}
