import java.io.IOException;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;
public class ComandLineArg {
	@Option(name="-p",usage="RMI Port")
    public  int num = 1099;
	
	 public void ParseArguments(String[] args) throws IOException {
	        CmdLineParser parser = new CmdLineParser(this);
	        try {
	            // parse the arguments.
	            parser.parseArgument(args);
	            System.out.println("starting at port "+ num);

	        } catch( CmdLineException e ) {
	            // if there's a problem in the command line,
	            // you'll get this exception. this will report
	            // an error message.
	            System.err.println(e.getMessage());
	            System.err.println("java SampleMain [options...] arguments...");
	            // print the list of available options
	            parser.printUsage(System.err);
	            System.err.println();

	            return;
	        }
	 }
}
